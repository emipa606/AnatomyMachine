﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using RimWorld;
using UnityEngine;
using Verse;


namespace LingMod
{
    public class Building_Dismemberment : Building_CryptosleepCasket
    {
        private WorkMode workMode = WorkMode.Modea;//默认是第一个工作模式
        public Pawn Pan => this.innerContainer.First() as Pawn;//寻取第一个内容物
        public override string GetInspectString()
        {
            string text = base.GetInspectString();
            string str;
            switch (workMode)
            {
                case WorkMode.Modea:
                    str = "ZuiDaLiYi".Translate();
                    break;
                case WorkMode.Modeb:
                    str = "WanQuanShouGe".Translate();
                    break;
                case WorkMode.Modec:
                default:
                    str = "ZiDingYi".Translate();
                    break;
            }
            return text + "\n " + "WorkMode".Translate() + "\n " + str;
        }//显示工作模式
        public override IEnumerable<Gizmo> GetGizmos()
        {
            foreach (Gizmo m in base.GetGizmos())
            {
                yield return m;
            }
            yield return new Command_Action()
            {
                defaultLabel = "NextMode".Translate(),
                defaultDesc = "NextModeDesc".Translate(),
                icon = DismembermentTieTu.XiaYiGe,

                action = delegate ()
                {
                    switch (workMode)
                    {
                        case WorkMode.Modea:
                            workMode = WorkMode.Modeb;
                            break;
                        case WorkMode.Modeb:
                            workMode = WorkMode.Modec;
                            break;
                        case WorkMode.Modec:
                            workMode = WorkMode.Modea;
                            break;
                        default:
                            break;
                    }

                }
            };//模式切换
            if (this.innerContainer.Any)
            {
                yield return new Command_Action()//执行解剖
                {
                    defaultLabel = "StartDismemberment".Translate(),
                    defaultDesc = "StartDismembermentDesc".Translate(),
                    icon = DismembermentTieTu.DongShou,

                    action = delegate ()
                    {
                        BoPi(Pan);
                    }
                };
                if (workMode == WorkMode.Modec)
                {
                    yield return new Command_Action()//开启选单界面
                    {
                        defaultLabel = "ZiDingYiMain".Translate(),
                        defaultDesc = "ZiDingYiMainDesc".Translate(),
                        icon = DismembermentTieTu.WoXiangXiang,

                        action = delegate ()
                        {
                            Find.WindowStack.Add(new ChooseBodypartWindow(this));
                        }
                    };
                }
            }

        }
        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref workMode, "workMode");
        }
        public void BoPi(Pawn pawn)
        {
            /*foreach (Hediff hediff in pawn.health.hediffSet.hediffs)
            {
                if (hediff.def.spawnThingOnRemoved != null)
                {
                    GenSpawn.Spawn(ThingMaker.MakeThing(hediff.def.spawnThingOnRemoved), this.InteractionCell, this.Map);
                    pawn.health.RemoveHediff(hediff);
                }
            }*/
            List<BodyPartRecord> Allpart = pawn.health.hediffSet.GetNotMissingParts().ToList();
            if (workMode == WorkMode.Modea)
            {
                foreach (BodyPartRecord part in Allpart)
                {
                    if (part.def.spawnThingOnRemoved != null && pawn.health.hediffSet.GetNotMissingParts().Contains(part) && (!part.IsCorePart))
                    {
                        pawn.health.AddHediff(HediffDefOf.MissingBodyPart, part);

                        GenSpawn.Spawn(ThingMaker.MakeThing(part.def.spawnThingOnRemoved), this.InteractionCell, this.Map);
                    }
                }
            }
            if (workMode == WorkMode.Modeb)
            {
                foreach (BodyPartRecord part in Allpart)
                {
                    if (pawn.health.hediffSet.GetNotMissingParts().Contains(part) && (!part.IsCorePart))
                    {
                        pawn.health.AddHediff(HediffDefOf.MissingBodyPart, part);
                        if (part.def.spawnThingOnRemoved != null)
                        {
                            GenSpawn.Spawn(ThingMaker.MakeThing(part.def.spawnThingOnRemoved), this.InteractionCell, this.Map);
                        }
                    }
                }
            }
            if (workMode == WorkMode.Modec)
            {
                foreach (BodyPartRecord part in modeCBodyparts)
                {
                    if (pawn.health.hediffSet.GetNotMissingParts().Contains(part) && (!part.IsCorePart))
                    {
                        pawn.health.AddHediff(HediffDefOf.MissingBodyPart, part);
                        if (part.def.spawnThingOnRemoved != null)
                        {
                            GenSpawn.Spawn(ThingMaker.MakeThing(part.def.spawnThingOnRemoved), this.InteractionCell, this.Map);
                        }
                    }
                }
            }
            for (int i = 0; i < 10; i++)
            {
                FilthMaker.MakeFilth(this.InteractionCell, this.Map, ThingDefOf.Filth_Blood);
            }

            this.innerContainer.TryDropAll(this.InteractionCell, this.Map,ThingPlaceMode.Near);
        }//(!part.IsCorePart)避免只移除最大部件
        public List<BodyPartRecord> bodyParts => Pan.health.hediffSet.GetNotMissingParts().ToList();
        public List<KeyValuePairsA<BodyPartRecord, bool>> pairsAs = new List<KeyValuePairsA<BodyPartRecord, bool>>();
        private List<BodyPartRecord> modeCBodyparts
        {
            get
            {
                List<BodyPartRecord> bodies = new List<BodyPartRecord>();
                foreach (KeyValuePairsA<BodyPartRecord, bool> item in pairsAs)
                {
                    if (item.Value)
                    {
                        bodies.Add(item.Key);
                    }
                }
                return bodies;
            }
        }
    }
    public enum WorkMode
    {
        Modea,
        Modeb,
        Modec

    }
    

    public class ChooseBodypartWindow : Window
    {
        public static string instructionString = "";
        public List<BodyPartRecord> bodyParts = new List<BodyPartRecord>();
        public Vector2 resultsAreaScroll;
        public override Vector2 InitialSize => new Vector2(640f, 480f);
        private Building_Dismemberment thing;
        public ChooseBodypartWindow(Building_Dismemberment thing)
        {
            this.optionalTitle = "ChooseBodypartWindowMain".Translate();
            this.preventCameraMotion = false;
            this.absorbInputAroundWindow = false;
            this.draggable = true;
            this.doCloseX = true;
            ChooseBodypartWindow.instructionString = Translator.Translate("ChooseBodypartWindowDesc");
            this.thing = thing;
            this.bodyParts = (from x in thing.bodyParts
                              where !x.IsCorePart
                              select x).ToList();
            thing.pairsAs.Clear();
            foreach (BodyPartRecord item in bodyParts)
            {
                thing.pairsAs.Add(new KeyValuePairsA<BodyPartRecord, bool>(item, false));
            }
        }
        public override void DoWindowContents(Rect inRect)
        {
            //throw new NotImplementedException();
            Text.Font = GameFont.Small;
            Rect rect = new Rect(inRect);
            rect.height = Text.CalcHeight(instructionString, rect.width) + 2f;
            Widgets.Label(rect, instructionString);
            Rect rect2 = new Rect(rect);
            rect2.y += rect.height + 2f;
            rect2.height = inRect.height - rect2.y - 2f;
            Rect rect3 = new Rect(rect2);
            rect3.width -= 16f;
            float num = Text.LineHeight * 2.25f + 2f;
            float num2 = thing.pairsAs.Count > 0 ? ((float)(thing.pairsAs.Count + 1) * num) : 0f;
            rect3.height = num2;
            Widgets.BeginScrollView(rect2, ref this.resultsAreaScroll, rect3, true);
            Rect rect4 = new Rect(rect3);
            rect4.height = num;

            if (thing.pairsAs.Count > 0)
            {
                foreach (KeyValuePairsA<BodyPartRecord, bool> BodyPart in thing.pairsAs)
                {
                    Widgets.DrawHighlightIfMouseover(rect4);
                    Rect rect6 = new Rect(rect4);
                    rect6.width = rect6.height;
                    Rect rectTemp = new Rect(rect6);
                    rectTemp.width *= 0.8f;
                    rectTemp.height = rectTemp.width;
                    Widgets.ThingIcon(rectTemp, thing.Pan, 1f);
                    Rect rect7 = new Rect(rect4);
                    rect7.width = rect7.width - rect6.width - num * 2f;
                    rect7.x += rect6.width;
                    string strr;
                    if (BodyPart.Key.customLabel == ""||BodyPart.Key.customLabel ==null)
                    {
                        strr = BodyPart.Key.LabelCap;
                    }
                    else
                    {
                        strr = BodyPart.Key.customLabel;
                    }
                    if (BodyPart.Key.def.spawnThingOnRemoved!=null)
                    {
                        strr = strr + " $" + BodyPart.Key.def.spawnThingOnRemoved.BaseMarketValue;
                    }
                    Widgets.Label(rect7, strr);
                    Rect rect8 = new Rect(rect4);
                    rect8.width = rect8.height;
                    rect8.x = rect7.x + rect7.width;
                    TooltipHandler.TipRegion(rect8, "ChooseBodypartWindowSel".Translate());
                    if (BodyPart.Value)
                    {
                        if (Widgets.ButtonImage(GenUI.ContractedBy(rect8, rect8.width / 4f), DismembermentTieTu.DuiDui))
                        {
                            if (thing is Building_Dismemberment tempThing)
                            {
                                //BodyPart.Value =!BodyPart.Value;
                                BodyPart.SetValue(false);
                                //this.Close();
                            }
                        }
                    }
                    else
                    {
                        if (Widgets.ButtonImage(GenUI.ContractedBy(rect8, rect8.width / 4f), DismembermentTieTu.BuBuDui))
                        {
                            if (thing is Building_Dismemberment tempThing)
                            {
                                //BodyPart.Value =!BodyPart.Value;
                                BodyPart.SetValue(true);
                                //this.Close();
                            }
                        }
                    }
                    Rect rect9 = new Rect(rect4);
                    rect9.width = rect9.height;
                    rect9.x = rect8.x + rect8.width;
                    if (BodyPart.Key.def.spawnThingOnRemoved != null)
                    {
                        Widgets.InfoCardButton(rect9.x + rect9.width / 2f - 12f, rect9.y + rect9.height / 2f - 12f, BodyPart.Key.def.spawnThingOnRemoved);
                        TooltipHandler.TipRegion(rect4, BodyPart.Key.def.spawnThingOnRemoved.DescriptionDetailed);
                    }
                    

                    rect4.y += num;
                }
            }
            Text.Anchor = TextAnchor.UpperLeft;
            Widgets.EndScrollView();
        }
    }

    public class KeyValuePairsA<T1, T2>
    {
        private BodyPartRecord key;
        private bool value;

        public BodyPartRecord Key
        {
            get
            {
                return this.key;
            }
        }

        public bool Value
        {
            get
            {
                return this.value;
            }
        }
        public void SetValue(bool value)
        {
            this.value = value;
        }
        public KeyValuePairsA(BodyPartRecord Key, bool value)
        {
            this.key = Key;
            this.value = value;
        }
    }
    [StaticConstructorOnStartup]
    public static class DismembermentTieTu
    {
        public static readonly Texture2D DuiDui = ContentFinder<Texture2D>.Get("UI/BoPiJi/DuiDui");
        public static readonly Texture2D BuBuDui = ContentFinder<Texture2D>.Get("UI/BoPiJi/BuBuDui");
        public static readonly Texture2D XiaYiGe = ContentFinder<Texture2D>.Get("UI/BoPiJi/XiaYiGe");
        public static readonly Texture2D WoXiangXiang = ContentFinder<Texture2D>.Get("UI/BoPiJi/WoXiangXiang");
        public static readonly Texture2D DongShou = ContentFinder<Texture2D>.Get("UI/BoPiJi/DongShou");
        
    }
}

